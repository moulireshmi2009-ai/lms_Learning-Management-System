<div class="navbar navbar-fixed-top navbar-inverse">
    <div class="navbar-inner">
        <div class="container-fluid">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <span class="brand" href="#">GPTC ADMIN PANEL</span>
            <div class="nav-collapse collapse">
                <ul class="nav pull-right">
                    <?php 
                        // Session ID sariya irukkannu check seigrom
                        $safe_session_id = isset($session_id) ? mysqli_real_escape_string($conn, $session_id) : '';
                        
                        $query = mysqli_query($conn, "select * from users where user_id = '$safe_session_id'") or die(mysqli_error($conn));
                        $row = mysqli_fetch_array($query);
                        
                        // Error varaamal irukka default values set seigrom
                        $firstname = isset($row['firstname']) ? $row['firstname'] : 'Admin';
                        $lastname = isset($row['lastname']) ? $row['lastname'] : '';
                    ?>
                    <li class="dropdown">
                        <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-user icon-large"></i>
                            <?php echo htmlspecialchars($firstname . ' ' . $lastname, ENT_QUOTES, 'UTF-8'); ?>
                            <i class="caret"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a tabindex="-1" href="#">Profile</a></li>
                            <li class="divider"></li>
                            <li>
                                <a tabindex="-1" href="logout.php"><i class="icon-signout"></i>&nbsp;Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>