<div class="pull-right">
    <footer>
        <p style="color: #000000; font-weight: bold;">Programmed by:MS / GPTC VANAVASI</p>
    </footer>
</div>