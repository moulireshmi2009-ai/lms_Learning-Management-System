<?php
 if (session_status() == PHP_SESSION_NONE) {
    session_start();
 }

// Check whether the session variable id is present or not
if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) { ?>
    <script>
        window.location = "index.php";
    </script>
<?php
    exit(); // Always exit after a redirect script
}

$session_id = $_SESSION['id'];
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE user_id = '$session_id'") or die(mysqli_error($conn));
$user_row = mysqli_fetch_array($user_query);
?>