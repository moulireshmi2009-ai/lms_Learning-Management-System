<div id="backup_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
        <h3 id="myModalLabel">Copy File to Folder?</h3>
    </div>
    
    <div class="modal-body">
        <center>
            <div class="control-group">
                <div class="controls">
                    <p><strong>Step 1: Choose Destination Folder (Class)</strong></p>
                    
                    <div class="control-group">
                        <div class="controls">
                            <select name="teacher_class_id" class="span12" required>
                                <option value="">-- Select Folder / Class --</option>
                                <?php 
                                // School year logic-ah thavirtu direct-ah teacher classes fetch pandrom for safety
                                $query = mysqli_query($conn,"select * from teacher_class
                                LEFT JOIN class ON class.class_id = teacher_class.class_id
                                LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
                                where teacher_id = '$session_id' ") or die(mysqli_error($conn));	
                                
                                if(mysqli_num_rows($query) > 0) {
                                    while($row = mysqli_fetch_array($query)){
                                ?>		
                                    <option value="<?php echo $row['teacher_class_id']; ?>">
                                        <?php echo $row['class_name']; ?> (<?php echo $row['subject_code']; ?>)
                                    </option>
                                <?php 
                                    }
                                } else {
                                    echo "<option value=''>No Classes Found</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <br>
                    <p class="alert alert-warning">
                        <i class="icon-info-sign"></i> 
                        Step 2: After choosing the folder, click 'Copy' to move your selected files.
                    </p>

                    <button name="share" class="btn btn-success btn-large">
                        <i class="icon-copy"></i> Copy / Share Now
                    </button>
                </div>
            </div>
        </center>
    </div>
    
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">
            <i class="icon-remove icon-large"></i> Close
        </button>
    </div>
</div>