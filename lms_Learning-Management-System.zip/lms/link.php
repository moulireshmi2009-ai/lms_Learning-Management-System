<div class="navbar">
    <div class="navbar-inner">
        <div class="container-fluid">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="nav-collapse collapse">
                <ul class="nav" id="footer_nav">
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li class="active">
                        <a href="index.php" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-home"></i>&nbsp;Home</a>
                    </li>
                    
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li>
                        <a href="about.php" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-info-sign"></i>&nbsp;About</a>
                    </li>
                    
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li>
                        <a href="calendar_of_events.php" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-calendar"></i>&nbsp;Calendar of Events</a>
                    </li>
                    
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li>
                        <a href="#directories" data-toggle="modal" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-phone"></i>&nbsp;Directories</a>
                    </li>
                    
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li>
                        <a href="#campuses" data-toggle="modal" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-building"></i>&nbsp;Campuses</a>
                    </li>
                    
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li>
                        <a href="history.php" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-file"></i>&nbsp;History</a>
                    </li>
                    
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                    <li>
                        <a href="developers.php" style="color: #ffffff !important; font-weight: 900; font-size: 16px; text-shadow: 3px 3px 5px #000000, -1px -1px 2px #000000;"><i class="icon-user"></i>&nbsp;Developers</a>
                    </li>
                    <li class="divider-vertical" style="border-right: 2px solid #ffffff; opacity: 0.7; height: 30px; margin-top: 5px;"></li>
                </ul>
            </div>
        </div>
    </div>
</div>