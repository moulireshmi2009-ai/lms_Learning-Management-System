<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
    <body>
        <?php include('navbar_teacher.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include('subject_overview_link.php'); ?>
                <div class="span9" id="content">
                    <div class="row-fluid">
                        <?php 
                        // Teacher details and Photo fetch panna indha query mukkiyam
                        $class_query = mysqli_query($conn,"select * from teacher_class
                                        LEFT JOIN class ON class.class_id = teacher_class.class_id
                                        LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
                                        LEFT JOIN teacher ON teacher.teacher_id = teacher_class.teacher_id
                                        where teacher_class_id = '$get_id'") or die(mysqli_error($conn));
                        $class_row = mysqli_fetch_array($class_query);
                        ?>

                        <div class="span3">
                            <img id="avatar" class="img-polaroid" src="admin/<?php echo $class_row['location']; ?>" style="width:150px; height:150px;">
                        </div>

                        <div class="span9">
                            <ul class="breadcrumb">
                                <li><a href="#"><?php echo $class_row['class_name'] ?? 'Class'; ?></a> <span class="divider">/</span></li>
                                <li><a href="#"><?php echo $class_row['subject_code'] ?? 'Subject'; ?></a> <span class="divider">/</span></li>
                                <li><a href="#"><b>Subject Overview</b></a></li>
                            </ul>
                        </div>
                        
                        <div id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                <div id="" class="muted pull-right">
                                    <?php 
                                    $query = mysqli_query($conn,"select * from teacher_class
                                        LEFT JOIN class_subject_overview ON class_subject_overview.teacher_class_id = teacher_class.teacher_class_id
                                        where class_subject_overview.teacher_class_id = '$get_id'") or die(mysqli_error($conn));
                                    $row = mysqli_fetch_array($query);
                                    $count = mysqli_num_rows($query);

                                    if ($count > 0 && isset($row['content']) && $row['content'] != ""){ ?>
                                        <a href="add_subject_overview.php<?php echo '?id='.$get_id; ?>" class="btn btn-info"><i class="icon-pencil"></i> Edit Subject Overview</a>
                                    <?php }else{ ?>
                                        <a href="add_subject_overview.php<?php echo '?id='.$get_id; ?>" class="btn btn-success"><i class="icon-plus-sign"></i> Add Subject Overview</a>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <?php 
                                    if (isset($row) && is_array($row) && isset($row['content']) && !empty($row['content'])) {
                                        echo $row['content']; 
                                    } else {
                                        echo "<div class='alert alert-info'>
                                                <i class='icon-info-sign'></i> No subject overview content added yet. 
                                              </div>";
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('footer.php'); ?>
        </div>
        <?php include('script.php'); ?>
    </body>
</html>