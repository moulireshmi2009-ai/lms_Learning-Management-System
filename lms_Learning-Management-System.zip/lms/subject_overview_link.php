<div class="span3" id="sidebar">
	<?php 
	// 1. மாணவர் லாகின் செய்திருந்தால் மாணவர் டேபிளில் இருந்தும், 
	// ஆசிரியர் லாகின் செய்திருந்தால் ஆசிரியர் டேபிளில் இருந்தும் டேட்டாவை எடுக்கும் Query
	$user_query = mysqli_query($conn,"select * from student where student_id = '$session_id'") or die(mysqli_error($conn));
	$user_row = mysqli_fetch_array($user_query);

	// ஒருவேளை மாணவர் இல்லை என்றால் (ஆசிரியராக இருந்தால்) ஆசிரியர் டேபிளில் தேடும்
	if(!$user_row){
		$user_query = mysqli_query($conn,"select * from teacher where teacher_id = '$session_id'") or die(mysqli_error($conn));
		$user_row = mysqli_fetch_array($user_query);
	}
	
	// 2. படம் இருக்கிறதா என்று செக் செய்கிறோம்
	$user_avatar = (isset($user_row['location']) && !empty($user_row['location'])) ? $user_row['location'] : 'images/index.jpg'; 
	?>
	
	<div style="text-align: center; margin-bottom: 10px;">
		<img id="avatar" src="admin/<?php echo $user_avatar; ?>" class="img-polaroid" style="width:140px; height:140px;">
		<br>
		<strong style="text-transform: uppercase;"><?php echo $user_row['firstname'] ?? ''; ?></strong>
	</div>
	
	<ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
		<li class=""><a href="dashboard_teacher.php"><i class="icon-chevron-right"></i><i class="icon-chevron-left"></i>&nbsp;Back</a></li>
		<li class=""><a href="my_students.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-group"></i>&nbsp;My Students</a></li>
		<li class="active"><a href="subject_overview.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-file"></i>&nbsp;Subject Overview</a></li>
		<li class=""><a href="downloadable.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-download"></i>&nbsp;Downloadable Materials</a></li>
		<li class=""><a href="assignment.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-book"></i>&nbsp;Assignments</a></li>
		<li class=""><a href="announcements.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-info-sign"></i>&nbsp;Announcements</a></li>
		<li class=""><a href="class_calendar.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-calendar"></i>&nbsp;Class Calendar</a></li>
		<li class=""><a href="class_quiz.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-list"></i>&nbsp;Quiz</a></li>
	</ul>
	<?php include('search_other_class.php'); ?>		
</div>