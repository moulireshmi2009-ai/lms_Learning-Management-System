<div class="span3" id="sidebar">
	<?php 
	// 1. Intha query mukkiam: Log-in panni irukkura teacher details-ah edukkum
	$teacher_query = mysqli_query($conn,"select * from teacher where teacher_id = '$session_id'") or die(mysqli_error($conn));
	$teacher_row = mysqli_fetch_array($teacher_query);
	
	// 2. Photo irukka nu check panni, path-ah set pannuthu
	$teacher_avatar = (isset($teacher_row['location']) && !empty($teacher_row['location'])) ? $teacher_row['location'] : 'images/uploads\SATHISHKUMAR.jpg'; 
	?>
	
	<img id="avatar" src="admin/<?php echo $teacher_avatar; ?>" class="img-polaroid">
	
	<ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
		<li class=""><a href="dashboard_teacher.php"><i class="icon-chevron-right"></i><i class="icon-chevron-left"></i>&nbsp;Back</a></li>
		<li class=""><a href="my_students.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-group"></i>&nbsp;My Students</a></li>
		<li class="active"><a href="subject_overview.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-file"></i>&nbsp;Subject Overview</a></li>
		<li class=""><a href="downloadable.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-download"></i>&nbsp;Downloadable Materials</a></li>
		<li class=""><a href="assignment.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-book"></i>&nbsp;Assignments</a></li>
		<li class=""><a href="announcements.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-info-sign"></i>&nbsp;Announcements</a></li>
		<li class=""><a href="class_calendar.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-calendar"></i>&nbsp;Class Calendar</a></li>
		<li class=""><a href="class_quiz.php<?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-list"></i>&nbsp;Quiz</a></li>
	</ul>
	<?php include('search_other_class.php'); ?>		
</div>