<div class="span3" id="sidebar">
	<?php 
	// 1. லாகின் செய்துள்ள நபரின் தகவலை எடுக்கும் Query (மாணவர் அல்லது ஆசிரியர்)
	$user_query = mysqli_query($conn,"select * from student where student_id = '$session_id'") or die(mysqli_error($conn));
	$user_row = mysqli_fetch_array($user_query);

	// மாணவர் இல்லை என்றால் ஆசிரியர் டேபிளில் தேடும்
	if(!$user_row){
		$user_query = mysqli_query($conn,"select * from teacher where teacher_id = '$session_id'") or die(mysqli_error($conn));
		$user_row = mysqli_fetch_array($user_query);
		$is_teacher = true;
	} else {
		$is_teacher = false;
	}
	
	// 2. படம் இருக்கிறதா என்று செக் செய்து பாதையை முடிவு செய்கிறோம்
	$user_avatar = (isset($user_row['location']) && !empty($user_row['location'])) ? $user_row['location'] : 'images/index.jpg'; 
	
	// மாணவர் என்றால் லிங்க்குகளில் _student.php என்று மாறும்
	$suffix = ($is_teacher) ? ".php" : "_student.php";
	?>
	
	<div style="text-align: center; margin-bottom: 15px;">
		<img id="avatar" src="admin/<?php echo $user_avatar; ?>" class="img-polaroid" style="width:140px; height:140px; object-fit: cover;">
		<br>
		<strong style="text-transform: uppercase; display: block; margin-top: 5px;">
			<?php echo ($user_row['firstname'] ?? '') . " " . ($user_row['lastname'] ?? ''); ?>
		</strong>
	</div>

	<ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
		<li class=""><a href="dashboard<?php echo $suffix; ?>"><i class="icon-chevron-right"></i><i class="icon-chevron-left"></i>&nbsp;Back</a></li>
		<li class=""><a href="my_students<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-group"></i>&nbsp;My Students</a></li>
		<li class=""><a href="subject_overview<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-file"></i>&nbsp;Subject Overview</a></li>
		<li class="active"><a href="downloadable<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-download"></i>&nbsp;Downloadable Materials</a></li>
		<li class=""><a href="assignment<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-book"></i>&nbsp;Assignments</a></li>
		<li class=""><a href="announcements<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-info-sign"></i>&nbsp;Announcements</a></li>
		<li class=""><a href="class_calendar<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-calendar"></i>&nbsp;Class Calendar</a></li>
		<li class=""><a href="class_quiz<?php echo $suffix; ?><?php echo '?id='.$get_id; ?>"><i class="icon-chevron-right"></i><i class="icon-list"></i>&nbsp;Quiz</a></li>
	</ul>
	<?php include('search_other_class.php'); ?>		
</div>