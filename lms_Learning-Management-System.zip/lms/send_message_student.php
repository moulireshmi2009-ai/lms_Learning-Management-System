<?php
// Intha query-ah unga file-la replace pannunga
$query_announcement = mysqli_query($conn,"SELECT * FROM message_sent 
    WHERE sender_id = '$session_id' 
    ORDER BY date_sended DESC") or die(mysqli_error($conn));

$count_my_message = mysqli_num_rows($query_announcement);
if ($count_my_message != '0'){
    while($row = mysqli_fetch_array($query_announcement)){
    $id = $row['message_sent_id'];
?>
    <div class="post" id="del<?php echo $id; ?>">
        <?php echo $row['content']; ?>
        <hr>
        Send to: <strong><?php echo $row['reciever_name']; ?></strong>
        <i class="icon-calendar"></i> <?php echo $row['date_sended']; ?>
        <div class="pull-right">
            <a class="btn btn-link" href="#<?php echo $id; ?>" data-toggle="modal"><i class="icon-remove"></i> Remove </a>
            <?php include("remove_sent_message_modal.php"); ?>
        </div>
    </div>
<?php }} else { ?>
    <div class="alert alert-info"><i class="icon-info-sign"></i> No Message in your Send Items</div>
<?php } ?>