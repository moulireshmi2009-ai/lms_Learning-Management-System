<div class="nav-collapse collapse">
    <ul class="nav pull-right">
        <?php 
            // Query-ku munnadi session check pannuvom
            $row = null;
            if(isset($session_id) && !empty($session_id)) {
                $query = mysqli_query($conn, "select * from student where student_id = '$session_id'") or die(mysqli_error($conn));
                $row = mysqli_fetch_array($query);
            }
        ?>
        <li class="dropdown">
            <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> 
                <i class="icon-user icon-large"></i>
                <?php 
                    // Inga row-la data irukkannu check panni display panrom
                    if($row) {
                        echo $row['firstname']." ".$row['lastname']; 
                    } else {
                        echo "Student Name"; // Data illana idhu theriyum
                    }
                ?> 
                <i class="caret"></i>
            </a>
        </li>
    </ul>
</div>