<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/NATHIN.jpg" class="img-circle">
										<hr>
										<p>Name: NATHIN .S</p>
										<p>Address: METTUR</p>
										<p>Email: nathins830@gmail.com</p>
										<p>Position: Programmer</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/THANOS.jpg" class="img-circle">
								<hr>
																				<p>Name:THANOSKUMAR .V</p>

										<p>Address: Tharamangalam</p>
										<p>Email: vthanoskumar@gmail.com</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/mark.jpg" class="img-circle">
								<hr>
												<p>Name: MOULISHANKAR .R</p>
										<p>Address: Tharamangalam</p>
										<p>Email: moulireshmi2009@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/RAMAN.jpg" class="img-circle">
								<hr>
												<p>Name: RAMAN .S</p>
										<p>Address: Tharamangalam</p>
										<p>Email: vjkiller50@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>