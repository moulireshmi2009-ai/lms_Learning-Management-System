<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
    <body>
		<?php include('navbar_student.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
				<?php include('my_classmates_link.php'); ?>
                <div class="span9" id="content">
                     <div class="row-fluid">
					 <?php 
						$query = mysqli_query($conn,"select * from teacher_class_student
							LEFT JOIN teacher_class ON teacher_class.teacher_class_id = teacher_class_student.teacher_class_id 
							LEFT JOIN class ON class.class_id = teacher_class.class_id 
							LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id 
							where teacher_class_student.teacher_class_id = '$get_id'") or die(mysqli_error());
						$row = mysqli_fetch_array($query);
					?>
					     <ul class="breadcrumb">
							<li><a href="#"><?php echo $row['class_name'] ?? 'Class'; ?></a> <span class="divider">/</span></li>
							<li><a href="#"><?php echo $row['subject_code'] ?? 'Subject'; ?></a> <span class="divider">/</span></li>
							<li><a href="#">School Year: <?php echo $row['school_year'] ?? ''; ?></a> <span class="divider">/</span></li>
							<li><a href="#"><b>My Classmates</b></a></li>
						</ul>
						<div id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                <div id="" class="muted pull-left">My Classmates</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
									<ul id="da-thumbs" class="da-thumbs">
										<?php
											$my_classmates = mysqli_query($conn,"select * from teacher_class_student
												LEFT JOIN student ON student.student_id = teacher_class_student.student_id
												where teacher_class_id = '$get_id' order by lastname ASC") or die(mysqli_error());
											
											if(mysqli_num_rows($my_classmates) > 0){
												while($row = mysqli_fetch_array($my_classmates)){
												$id = $row['teacher_class_student_id'];
										?>
											<li id="del<?php echo $id; ?>">
												<a href="#">
													<img src="admin/<?php echo $row['location']; ?>" width="124" height="140" class="img-polaroid" alt="">
													<div>
														<span><p><?php echo $row['firstname']." ".$row['lastname']; ?></p></span>
													</div>
												</a>
											</li>
										<?php 
												} 
											} else {
												echo "<div class='alert alert-info'><i class='icon-info-sign'></i> No classmates found in this class.</div>";
											}
										?>
									</ul>
                                </div>
                            </div>
                        </div>
                        </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>