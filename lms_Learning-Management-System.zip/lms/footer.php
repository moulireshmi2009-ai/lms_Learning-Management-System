<center>
    <footer>
        <p style="color: #000000 !important; font-weight: 900; font-size: 16px; letter-spacing: 1px;">
            GPTC VANAVASI LMS Copyright 2026
        </p>
    </footer>
</center>