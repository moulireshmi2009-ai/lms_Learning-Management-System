<?php
include('admin/dbcon.php');
include('session.php');

if (isset($_POST['share'])){

    // LINE 5 FIX: Check if selector exists and is an array
    if (isset($_POST['selector']) && is_array($_POST['selector'])) {
        
        $id = $_POST['selector'];
        $class_id = isset($_POST['teacher_class_id']) ? $_POST['teacher_class_id'] : '';
        
        // LINE 8 FIX: count() safe-ah panna idhu help pannum
        $N = count($id);
        
        for($i=0; $i < $N; $i++) {
            // Table name space remove panni iruken (teacher_shared_id)
            $result = mysqli_query($conn,"select * from teacher_shared where teacher_shared_id = '$id[$i]' ") or die(mysqli_error($conn));
            
            while($row = mysqli_fetch_array($result)){
                $fname = $row['fname'];
                $floc = $row['floc'];
                $fdesc = $row['fdesc'];
                
                // insert into files... value-ah values-nu maathi iruken (SQL standard)
                mysqli_query($conn,"insert into files (floc,fdatein,fdesc,class_id,fname,teacher_id) values('$floc',NOW(),'$fdesc','$class_id','$fname','$session_id')") or die(mysqli_error($conn));
            }
        }
        ?>
        <script>
            window.location = 'downloadable.php<?php echo '?id='.$class_id; ?>';
        </script>
        <?php 
    } else {
        // Oruvelai file select pannama click panna error varaama back poga:
        ?>
        <script>
            alert('Please select at least one file to share!');
            window.history.back();
        </script>
        <?php
    }
}
?>