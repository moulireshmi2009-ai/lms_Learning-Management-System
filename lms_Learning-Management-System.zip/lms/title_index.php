<div class="row-fluid">
    <div class="span4">
        <img class="index_logo" src="admin/images/Logo.png">
    </div>	
    <div class="span8">
        <div class="title">
            <span><p class="GPTC" style="color: #FFFFFF; font-size: 16px; font-weight: bold;">GOVERNMENT POLYTECHNIC COLLEGE</p></span>
            <h3>
                <p style="color: #FFFFFF; font-size: 24px; font-weight: bold;">GOVERNMENT POLYTECHNIC COLLEG,VANAVASI</p>
            </h3>
        </div>
    </div>							
</div>

<div class="row-fluid">
    <div class="span12">
        <br>
        <div class="motto">
            <h3 style="color: #FFFFFF; font-weight: bold;">LEARNING MANAGEMENT SYSTEM</h3>
        </div>		
    </div>		
</div>