<div class="span3" id="">
    <div class="row-fluid">
        <div class="block">
            <div class="navbar navbar-inner block-header">
                <div id="" class="muted pull-left"><h4><i class="icon-pencil"></i> Create Message</h4></div>
            </div>
            <div class="block-content collapse in">
                <div class="span12">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="student_message.php">For Teacher</a></li>
                        <li><a href="student_message_student.php">For Student</a></li>
                    </ul>

                    <form method="post" id="send_message">
                        <div class="control-group">
                            <label>To:</label>
                            <div class="controls">
                                <select name="teacher_id" class="chzn-select" required>
                                    <option value=""></option>
                                    <?php
                                    $query = mysqli_query($conn,"select * from teacher order by firstname");
                                    while($row = mysqli_fetch_array($query)){
                                    ?>
                                    <option value="<?php echo $row['teacher_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?> </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="control-group">
                            <label>Content:</label>
                            <div class="controls">
                                <textarea name="my_message" class="my_message" style="width:100%; height:100px;" required></textarea>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="controls">
                                <button type="submit" class="btn btn-success"><i class="icon-envelope-alt"></i> Send </button>
                            </div>
                        </div>
                    </form>

                    <script>
                    jQuery(document).ready(function(){
                        jQuery("#send_message").submit(function(e){
                            e.preventDefault();
                            var formData = jQuery(this).serialize();
                            $.ajax({
                                type: "POST",
                                url: "send_message_student.php",
                                data: formData,
                                success: function(html){
                                    // Successfully sent jGrowl notification
                                    $.jGrowl("Message Successfully Sent", { header: 'Message Sent' });
                                    var delay = 2000;
                                    // Redirect to SENT messages to see the result
                                    setTimeout(function(){ window.location = 'sent_message_student.php'; }, delay);  
                                }
                            });
                            return false;
                        });
                    });
                    </script>
                </div>
            </div>
        </div>
        </div>
</div>